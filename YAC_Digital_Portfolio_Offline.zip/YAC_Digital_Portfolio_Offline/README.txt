================================================================================
     SRHR Youth Advocacy Champions: Digital Portfolio (Offline Edition)
     Centre for the Study of Adolescence (CSA Kenya) · INSPIRE Lab
================================================================================

WELCOME! This offline package lets you review the complete digital portfolio
with zero internet access or Wi-Fi required.

HOW TO OPEN (NON-TECHNICAL & INSTANT):
Simply double-click the file named:
    👉 "Open_Portfolio.html"

• It opens directly in your standard web browser (Google Chrome, Microsoft Edge,
  Apple Safari, or Firefox).
• NO command prompt (black terminal window) will ever open.
• All fonts (Newsreader and Manrope), photos, interactive maps, and champion
  profiles are completely self-contained.
• You can click on any champion card or map avatar to open their full verified
  dossier modal.

HOW TO VIEW OR PRINT THE FULL EXECUTIVE DOSSIER:
• Double-click "Print_PDF_Dossier.html" (or click "PDF Dossier" in the top bar
  of the portfolio).
• Click the "Print / Save as PDF" button at the top to print or export an executive
  summary document for stakeholders.

HOW CSA CAN UPDATE PROFILES & MAINTAIN THE PORTFOLIO:
• Double-click "CSA_PORTFOLIO_MAINTENANCE_GUIDE.html" (or click "Guide" in the top bar).
• You can also read "HOW_TO_UPDATE_PROFILES.txt" or "CSA_PORTFOLIO_MAINTENANCE_GUIDE.md".

================================================================================
Centre for the Study of Adolescence (CSA Kenya)
Website: csakenya.org
================================================================================
